const express = require('express');
const multer = require('multer');
const OpenAI = require('openai');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = process.env.PORT || 3000;
const upload = multer({storage: multer.memoryStorage(), limits:{fileSize:8*1024*1024}, fileFilter(_req,file,cb){cb(null,['image/jpeg','image/png','image/webp'].includes(file.mimetype));}});
const client = new OpenAI({apiKey:process.env.OPENAI_API_KEY});
app.disable('x-powered-by');
app.use(express.static(path.join(__dirname,'../web')));
app.get('/health',(_req,res)=>res.json({ok:true}));

const schema = {type:'object',additionalProperties:false,properties:{
 kind:{type:'string',enum:['passage','questions','mixed','unclear']},
 passage_relation:{type:'string',enum:['new','continuation','same','uncertain','none']},
 passage_text:{type:'string'},
 passage_signature:{type:'string'},
 answers:{type:'array',items:{type:'object',additionalProperties:false,properties:{number:{type:'string'},answer:{type:'string'},confidence:{type:'string',enum:['high','medium','low']}},required:['number','answer','confidence']}},
 needs_rescan:{type:'boolean'}
},required:['kind','passage_relation','passage_text','passage_signature','answers','needs_rescan']};

app.post('/api/answer',upload.single('image'),async(req,res)=>{
 try{
  if(!process.env.OPENAI_API_KEY) return res.status(503).json({error:'서버 API 키 설정을 확인해 주세요.'});
  if(!req.file) return res.status(400).json({error:'JPEG/PNG/WebP 이미지를 전송해 주세요.'});
  const previous = String(req.body.passage||'').slice(0,24000);
  const signature = String(req.body.signature||'').slice(0,160);
  const dataUrl=`data:${req.file.mimetype};base64,${req.file.buffer.toString('base64')}`;
  const prompt=`너는 한국어 수능/모의고사 및 일반 학습 문제를 사진에서 판독하는 분석기다. 내부적으로 충분히 검토하되 JSON만 출력한다.
사진을 passage(지문만), questions(문항/선지), mixed(둘 다), unclear로 분류한다. 문제 번호가 여러 개면 모두 처리한다. 긴 독서/문학 지문은 문단 순서대로 가능한 한 정확히 전사하여 passage_text에 넣는다. 지문이 읽히지 않으면 추측하여 전사하지 않는다. 지문이 없으면 passage_text는 빈 문자열이다.
이전 지문과 비교하여 passage_relation을 new/continuation/same/uncertain/none으로 분류한다. continuation은 확실히 이어지는 새 내용일 때만, new는 확실히 별개 지문일 때만 선택한다. 애매하면 uncertain을 선택하여 기존 지문을 보호한다. passage_signature에는 지문 첫 문장의 짧은 특징 문구를 적는다.
문제 풀이 시 현재 사진의 지문과 이전 지문을 모두 참고한다. 특히 국어는 지문 논지, 문단 관계, 조건/인과/대조, 선지 ①~⑤의 정확한 표현을 대조하고, 과장/범위/주체 변경/없는 추론을 검토한다. 지문 근거가 최우선이다. 여러 문항이면 각각 독립적으로 검증한다. 내부 검토는 출력하지 않는다.
정답은 문항번호와 선택지 번호 또는 짧은 정답만 기입한다. 확실히 판독하지 못한 문제는 답을 지어내지 말고 answer를 빈 문자열로 하며 needs_rescan=true로 표시한다. 사진에 문제가 없으면 answers는 빈 배열이다.
이전 지문 특징: ${signature||'(없음)'}
이전 지문 내용:\n${previous||'(없음)'}`;
  const result=await client.responses.create({model:process.env.OPENAI_MODEL||'gpt-4.1-mini',max_output_tokens:3500,
   input:[{role:'user',content:[{type:'input_text',text:prompt},{type:'input_image',image_url:dataUrl,detail:'high'}]}],
   text:{format:{type:'json_schema',name:'scan_result',strict:true,schema}}});
  const data=JSON.parse(result.output_text||'{}');
  const answers=(data.answers||[]).filter(a=>a.answer).map(a=>({number:a.number,answer:a.answer,confidence:a.confidence}));
  res.set('Cache-Control','no-store');
  res.json({kind:data.kind,passage_relation:data.passage_relation,passage_text:data.passage_text||'',passage_signature:data.passage_signature||'',answers,answer:answers.map(a=>`${a.number ? a.number+'번: ' : ''}${a.answer}`).join('\n'),needs_rescan:data.needs_rescan,question_fingerprint:crypto.createHash('sha256').update(JSON.stringify(answers)).digest('hex').slice(0,16)});
 }catch(err){console.error('Scan error:',err.status||'',err.message);res.status(500).json({error:'AI 분석에 실패했습니다. API 잔액·모델 설정·서버 로그를 확인해 주세요.'});}
});
app.use((err,_req,res,_next)=>res.status(400).json({error:err.code==='LIMIT_FILE_SIZE'?'이미지는 8MB 이하여야 합니다.':'이미지 업로드 오류'}));
app.listen(PORT,()=>console.log(`Server listening on ${PORT}`));
