AI 문제 자동 인식 앱 v2

추가 기능: 지문 자동 판별/저장, 여러 페이지 이어붙이기(판별이 확실할 때), 이전 지문을 이용한 문항 풀이, 다중 문항 답변, 카메라 화면 변화 감지.

배포: ZIP을 압축 해제하여 저장소 최상위에 web/ 과 server/ 폴더가 나란히 위치하도록 업로드하세요.
Render Root Directory: 비워 둠
Build Command: cd server && npm install
Start Command: cd server && npm start
Environment: OPENAI_API_KEY (Render에만 저장), OPENAI_MODEL (선택, 기본 gpt-4.1-mini)

기존 Render 서비스가 ZIP을 직접 unzip하도록 설정되었다면 위 명령을 그대로 쓰기 전에 현재 저장소 구조와 맞춰야 합니다.

지문은 브라우저 localStorage에 최대 24시간 보존되며, 해당 브라우저/기기에서만 이어집니다. 민감한 개인정보가 담긴 사진은 촬영하지 마세요. 이미지와 지문 텍스트는 답변을 위해 서버 및 OpenAI API로 전송됩니다. 브라우저의 사이트 데이터 삭제 시 저장 지문도 삭제됩니다.

주의: 모델의 지문 판별/정답률은 보장되지 않습니다. 실제 아이폰, Render, API 연결 및 기출 문제 테스트는 배포 후 별도 확인이 필요합니다. 카메라 움직임 감지로 호출 수를 줄이지만 완전한 중복 방지는 아닙니다.
