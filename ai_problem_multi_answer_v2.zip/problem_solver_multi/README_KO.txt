AI 문제 자동 답변 - 여러 문제 동시 인식 버전

변경 사항
- 한 화면에 보이는 여러 문제를 위에서 아래 순서로 읽고 번호별 정답만 표시합니다.
- 답변이 실패하면 API 키 오류, 사용 한도 오류 등 가능한 원인을 화면에 표시합니다.
- 동일한 문제/답 조합은 중복 표시하지 않습니다.
- 카메라 프레임 전송 간격은 8초입니다. API 사용량과 비용이 발생할 수 있습니다.

GitHub 업로드
1. ZIP 파일 자체를 올리지 말고 먼저 압축을 풉니다.
2. 저장소 루트에 server 폴더, web 폴더, README_KO.txt가 보이도록 업로드합니다.
3. 기존 server, web 폴더가 있다면 새 파일로 교체합니다.
4. server 폴더 안에 package.json과 server.js가 있어야 합니다.

Render 설정
- Runtime: Node
- Build Command: cd server && npm install
- Start Command: cd server && npm start
- Environment 변수: OPENAI_API_KEY = 본인의 OpenAI API 키
- 선택 환경변수: OPENAI_MODEL = gpt-4.1-mini
- 저장 후 Manual Deploy > Deploy latest commit

중요
- OPENAI_API_KEY를 GitHub, HTML, 이 채팅에 올리지 마세요. Render Environment에만 입력하세요.
- 카메라 이미지는 서버를 거쳐 AI 서비스로 전송됩니다. 개인정보/민감한 자료를 비추지 마세요.
- AI가 틀릴 수 있으므로 정답을 반드시 확인하세요.
- 여러 문제가 작고 흐리게 보이면 일부를 놓칠 수 있습니다. 한 화면에 문제를 너무 많이 넣지 말고 글자가 선명하게 보이게 하세요.
