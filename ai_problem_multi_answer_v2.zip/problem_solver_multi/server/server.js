const express = require('express');
const multer = require('multer');
const OpenAI = require('openai');
const path = require('path');
const crypto = require('crypto');

const app = express();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (file.mimetype && file.mimetype.startsWith('image/')) cb(null, true);
    else cb(new Error('이미지 파일만 보낼 수 있습니다.'));
  }
});
const PORT = process.env.PORT || 3000;
app.use(express.static(path.join(__dirname, '../web')));

app.get('/health', (_req, res) => res.json({ ok: true }));

app.post('/api/answer', upload.single('image'), async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY || !process.env.OPENAI_API_KEY.trim()) {
      return res.status(503).json({ error: 'Render 환경변수에 OPENAI_API_KEY가 등록되지 않았습니다.' });
    }
    if (!req.file) return res.status(400).json({ error: '카메라 이미지가 전송되지 않았습니다.' });

    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const mime = req.file.mimetype || 'image/jpeg';
    const dataUrl = `data:${mime};base64,${req.file.buffer.toString('base64')}`;
    const schema = {
      type: 'object',
      additionalProperties: false,
      properties: {
        questions: {
          type: 'array',
          items: {
            type: 'object',
            additionalProperties: false,
            properties: {
              number: { type: 'string' },
              answer: { type: 'string' }
            },
            required: ['number', 'answer']
          }
        }
      },
      required: ['questions']
    };

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || 'gpt-4.1-mini',
      max_output_tokens: 1200,
      text: { format: { type: 'json_schema', name: 'problem_answers', strict: true, schema } },
      input: [{
        role: 'user',
        content: [
          { type: 'input_text', text: '이미지에 보이는 학습 문제를 위에서 아래 순서로 모두 찾아 각각 풀어라. 여러 문제가 있으면 모두 반환하고, 하나만 있으면 하나만 반환한다. 문제 번호가 보이면 그대로 number에 쓰고, 번호가 없으면 1, 2, 3 순서로 붙인다. answer에는 정답만 짧게 쓴다. 풀이 과정, 설명, 인사말은 쓰지 않는다. 글자가 잘려 있거나 문제를 판독할 수 없어 정답을 확실히 구할 수 없는 문제는 임의로 추측하지 말고 해당 항목을 생략한다. 문제와 선택지가 모두 보이면 선택지 기호와 답을 함께 쓴다. 반환 형식은 지정된 JSON 스키마를 따른다.' },
          { type: 'input_image', image_url: dataUrl, detail: 'high' }
        ]
      }]
    });

    const raw = (response.output_text || '').trim();
    if (!raw) return res.status(502).json({ error: 'AI가 답을 반환하지 않았습니다. 문제를 더 선명하게 비춰 다시 시도해 주세요.' });
    let parsed;
    try { parsed = JSON.parse(raw); }
    catch (_e) { return res.status(502).json({ error: 'AI 답변 형식을 읽지 못했습니다. 다시 시도해 주세요.' }); }

    const questions = Array.isArray(parsed.questions)
      ? parsed.questions.filter(q => q && String(q.answer || '').trim()).slice(0, 20).map((q, i) => ({
          number: String(q.number || i + 1).slice(0, 20),
          answer: String(q.answer).trim().slice(0, 500)
        }))
      : [];
    const fingerprint = crypto.createHash('sha256').update(JSON.stringify(questions)).digest('hex');
    return res.json({ questions, fingerprint });
  } catch (err) {
    console.error('Problem answer API error:', { status: err.status, code: err.code, type: err.type, message: err.message });
    const status = Number.isInteger(err.status) && err.status >= 400 && err.status < 600 ? err.status : 500;
    let message = '서버에서 답변을 처리하지 못했습니다.';
    if (status === 401) message = 'OpenAI API 키가 올바르지 않습니다. Render 환경변수의 키를 확인해 주세요.';
    else if (status === 429) message = 'OpenAI API 사용 한도 또는 결제 한도에 도달했습니다. API 결제와 사용 한도를 확인해 주세요.';
    else if (status === 400) message = '요청 형식 또는 모델 설정에 문제가 있습니다. Render 로그를 확인해 주세요.';
    else if (err.message && /timeout|timed out/i.test(err.message)) message = 'AI 응답 시간이 초과됐습니다. 잠시 후 다시 시도해 주세요.';
    return res.status(status).json({ error: message, code: err.code || 'SERVER_ERROR' });
  }
});

app.use((err, _req, res, _next) => {
  console.error('Upload error:', err.message);
  res.status(400).json({ error: err.message || '이미지를 업로드하지 못했습니다.' });
});

app.listen(PORT, () => console.log(`Server listening on ${PORT}`));
