const express = require("express");
const multer = require("multer");
const OpenAI = require("openai");
const path = require("path");

const app = express();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 8 * 1024 * 1024 } });
const PORT = process.env.PORT || 3000;
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

app.use(express.static(path.join(__dirname, "../web")));

app.get("/health", (_req, res) => res.json({ ok: true }));

app.post("/api/answer", upload.single("image"), async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) return res.status(500).json({ error: "서버에 OPENAI_API_KEY가 설정되지 않았습니다." });
    if (!req.file) return res.status(400).json({ error: "이미지가 전송되지 않았습니다." });

    const mime = req.file.mimetype || "image/jpeg";
    const dataUrl = `data:${mime};base64,${req.file.buffer.toString("base64")}`;
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
      input: [{
        role: "user",
        content: [
          { type: "input_text", text: "이미지 속 학습 문제를 읽고 정답만 한국어로 답하세요. 풀이, 설명, 인사말은 쓰지 마세요. 문제가 없거나 읽을 수 없으면 답을 추측하지 말고 빈 문자열로 답하세요. 객관식은 선택지 번호 또는 기호와 답을 함께 간단히 쓰세요." },
          { type: "input_image", image_url: dataUrl }
        ]
      }]
    });
    const answer = (response.output_text || "").trim();
    const fingerprint = answer ? Buffer.from(answer).toString("base64").slice(0, 32) : "";
    res.json({ answer, subject: "", question_fingerprint: fingerprint });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "답변 처리 중 오류가 발생했습니다. 잠시 후 다시 시도해 주세요." });
  }
});

app.listen(PORT, () => console.log(`Server listening on ${PORT}`));