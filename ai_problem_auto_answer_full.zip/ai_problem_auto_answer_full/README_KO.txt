AI 문제 자동 답변 앱 - 배포 안내

구성
- web/: 휴대폰 브라우저 카메라 화면
- server/: 이미지 문제를 OpenAI API로 보내 답만 반환하는 Node.js 서버

중요
- 이 파일은 앱 소스 코드입니다. 아직 인터넷에 배포되거나 앱스토어에 등록된 앱은 아닙니다.
- 실제 사용에는 OpenAI API 키와 별도 API 결제가 필요합니다.
- API 키를 HTML, GitHub 저장소, 채팅에 올리지 마세요. Render의 Environment Variables에만 입력하세요.
- 카메라 이미지는 서버를 거쳐 AI API로 전송됩니다. 민감한 문서나 개인정보가 있는 화면은 비추지 마세요.
- AI가 문제를 잘못 읽거나 답을 틀릴 수 있습니다. 학습 확인용으로 사용하세요.

Render 배포 (GitHub 저장소에 이 압축을 푼 파일/폴더를 업로드한 뒤)
1. Render에서 New + > Web Service
2. GitHub 저장소 선택
3. Runtime: Node
4. Build Command: cd server && npm install
5. Start Command: cd server && npm start
6. Environment 탭에서 OPENAI_API_KEY 이름으로 API 키 추가
7. 배포 후 생성된 https 주소로 아이폰 Safari에서 접속하고 카메라 권한 허용

저장소 루트에 web 폴더와 server 폴더가 나란히 있어야 합니다.
카메라 기능은 HTTPS에서만 정상 작동합니다.

비용/운영 주의
- 현재 카메라는 약 5초마다 이미지를 AI 서버로 전송합니다. 사용량에 따라 API 비용과 데이터 사용량이 발생할 수 있습니다.
- 실제 공개 서비스 전에는 로그인, 요청 제한(rate limit), 비용 한도, 개인정보 안내 등을 추가하세요.
